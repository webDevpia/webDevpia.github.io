import './App.css';
import { Navbar, Container, Nav} from 'react-bootstrap'
import data from './db/fruit'; 
import { useState } from 'react';
import Products from './components/Products';

function App() {

  let [fruit] = useState(data); 
  console.log(fruit[0].price);

  return (
    <div className="App">

        <Navbar bg="dark" data-bs-theme="dark">
        <Container>
          <Navbar.Brand href="#home">과일농장</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link href="#home">Home</Nav.Link>
            <Nav.Link href="#features">상세페이지</Nav.Link>
            <Nav.Link href="#pricing">장바구니</Nav.Link>
          </Nav>
        </Container>
      </Navbar>

      <div className="slider"></div>

      <div className="container" style={{textAlign:"center"}}> 
        <div className="row">
         {
            fruit.map((ele,i)=>{
            return(
            <Products fruit={fruit[i]}  i={i} key={data[i].id} /> )
            })
          }

        </div> 
      </div>
    </div>
  );
}

export default App;
